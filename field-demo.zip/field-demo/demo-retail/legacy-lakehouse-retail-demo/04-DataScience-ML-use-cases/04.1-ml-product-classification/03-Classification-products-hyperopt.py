# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Notebook under construction, will be available soon
# MAGIC 
# MAGIC <!-- Collect usage data (view). Remove it to disable collection. View README for more details.  -->
# MAGIC <img width="1px" src="https://www.google-analytics.com/collect?v=1&gtm=GTM-NKQ8TT7&tid=UA-163989034-1&cid=555&aip=1&t=event&ec=field_demos&ea=display&dp=%2F42_field_demos%2Fretail%2Fml%2Fproduct_classification%2Fml_product_classification_03&dt=ML">
# MAGIC <!-- [metadata={"description":"Use hyperopt to distribute model hyperparameter tuning.<br/><i>Usage: advanced MLFlow demo, hyperopt.</i>",
# MAGIC  "authors":["quentin.ambard@databricks.com"],
# MAGIC  "db_resources":{},
# MAGIC   "search_tags":{"vertical": "retail", "step": "Data Science", "components": ["auto-ml", "mlflow", "hyperopt"]},
# MAGIC                  "canonicalUrl": {"AWS": "", "Azure": "", "GCP": ""}}] -->