# Databricks notebook source
dbutils.widgets.dropdown("reset_all_data", "false", ["true", "false"], "Reset all data")
dbutils.widgets.text("catalog", "", "Catalog")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC # Ingesting and transforming IOT sensors from Wind Turbinge using Delta Lake and Spark API
# MAGIC 
# MAGIC <img style="float: right" width="300px" src="https://raw.githubusercontent.com/QuentinAmbard/databricks-demo/main/retail/resources/images/lakehouse-retail/lakehouse-retail-churn-2.png" />
# MAGIC 
# MAGIC In this notebook, we'll show you an alternative to Delta Live Table: building an ingestion pipeline with the Spark API.
# MAGIC 
# MAGIC As you'll see, this implementation is lower level than the Delta Live Table pipeline, and you'll have control over all the implementation details (handling checkpoints, data quality etc).
# MAGIC 
# MAGIC Lower level also means more power. Using Spark API, you'll have unlimited capabilities to ingest data in Batch or Streaming.
# MAGIC 
# MAGIC If you're unsure what to use, start with Delta Live Table!
# MAGIC 
# MAGIC *Remember that Databricks workflow can be used to orchestrate a mix of Delta Live Table pipeline with standard Spark pipeline.*
# MAGIC 
# MAGIC ### Dataset:
# MAGIC 
# MAGIC As reminder, we have multiple data sources coming from different system:
# MAGIC 
# MAGIC * <strong>Spare part stock</strong>: coming from our SAP system, with a list of our current stock per region. Knowing our present stock and type of failure will help us adjust and dispatch stock dynamically.
# MAGIC * <strong>Turbine metadata</strong>: Turbine ID, location (1 row per turbine)
# MAGIC * <strong>Turbine sensor stream</strong>: Realtime streaming flow from wind turbine sensor (vibration, energy produced, speed etc)
# MAGIC * <strong>Turbine status</strong>: Historical turbine status based to analyse which part is faulty (used as label in our ML model)
# MAGIC 
# MAGIC 
# MAGIC Leveraging Spark and Delta Lake makes such an implementation easy.
# MAGIC 
# MAGIC <!-- Collect usage data (view). Remove it to disable collection. View README for more details.  -->
# MAGIC <img width="1px" src="https://www.google-analytics.com/collect?v=1&gtm=GTM-NKQ8TT7&tid=UA-163989034-1&cid=555&aip=1&t=event&ec=field_demos&ea=display&dp=%2F42_field_demos%2Fretail%2Flakehouse_churn%2Fdelta_pipeline&dt=LAKEHOUSE_RETAIL_CHURN">

# COMMAND ----------

# MAGIC %run ../../_resources/00-setup $reset_all_data=$reset_all_data $catalog=$catalog

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Building a Spark Data pipeline with Delta Lake
# MAGIC 
# MAGIC In this example, we'll implement a end 2 end pipeline consuming our IOT sources. We'll use the medaillon architecture but could build a star schema, data vault or any other modelisation.
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC This can be challenging with traditional systems due to the following:
# MAGIC  * Data quality issue
# MAGIC  * Running concurrent operation
# MAGIC  * Running DELETE/UPDATE/MERGE over files
# MAGIC  * Governance & schema evolution
# MAGIC  * Performance ingesting millions of small files on cloud buckets
# MAGIC  * Processing & analysing unstructured data (image, video...)
# MAGIC  * Switching between batch or streaming depending of your requirement...
# MAGIC 
# MAGIC ## Solving these challenges with Delta Lake
# MAGIC 
# MAGIC <div style="float:left">
# MAGIC 
# MAGIC **What's Delta Lake? It's a new OSS standard to bring SQL Transactional database capabilities on top of parquet files!**
# MAGIC 
# MAGIC Used as a new Spark format, built on top of Spark API / SQL
# MAGIC 
# MAGIC * **ACID transactions** (Multiple writers can simultaneously modify a data set)
# MAGIC * **Full DML support** (UPDATE/DELETE/MERGE)
# MAGIC * **BATCH and STREAMING** support
# MAGIC * **Data quality** (expectatiosn, Schema Enforcement, Inference and Evolution)
# MAGIC * **TIME TRAVEL** (Look back on how data looked like in the past)
# MAGIC * **Performance boost** with ZOrder, data skipping and Caching, solves small files issue 
# MAGIC </div>
# MAGIC 
# MAGIC 
# MAGIC <img src="https://pages.databricks.com/rs/094-YMS-629/images/delta-lake-logo.png" style="height: 200px"/>
# MAGIC 
# MAGIC <br style="clear: both">
# MAGIC 
# MAGIC We'll incrementally load new data with the autoloader, enrich this information and then load a model from MLFlow to perform our predictive maintenance forecast.
# MAGIC 
# MAGIC This information will then be used to build our DBSQL dashboard to analyse current turbine farm and impact on stock.
# MAGIC 
# MAGIC Let'simplement the following flow: 
# MAGIC  
# MAGIC <div><img width="1100px" src="https://github.com/databricks-demos/dbdemos-resources/raw/main/images/manufacturing/lakehouse-iot-turbine/lakehouse-manuf-iot-turbine-spark-full.png"/></div>
# MAGIC 
# MAGIC *Note that we're including the ML model our [Data Scientist built](TODO) using Databricks AutoML to predict the churn.*

# COMMAND ----------

# MAGIC %md
# MAGIC ## ![](https://pages.databricks.com/rs/094-YMS-629/images/delta-lake-tiny-logo.png) 1/ Explore the dataset
# MAGIC 
# MAGIC Let's review the files being received

# COMMAND ----------

# MAGIC %fs ls /demos/manufacturing/iot_turbine/incoming_data

# COMMAND ----------

# DBTITLE 1,Review the raw sensor data received as JSON
# MAGIC %sql
# MAGIC SELECT * FROM json.`/demos/manufacturing/iot_turbine/incoming_data`

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### 1/ Loading our data using Databricks Autoloader (cloud_files)
# MAGIC <div style="float:right">
# MAGIC   <img width="700px" src="https://github.com/databricks-demos/dbdemos-resources/raw/main/images/manufacturing/lakehouse-iot-turbine/lakehouse-manuf-iot-turbine-spark-1.png"/>
# MAGIC </div>
# MAGIC   
# MAGIC Autoloader allow us to efficiently ingest millions of files from a cloud storage, and support efficient schema inference and evolution at scale.
# MAGIC 
# MAGIC For more details on autoloader, run `dbdemos.install('auto-loader')`
# MAGIC 
# MAGIC Let's use it to [create our pipeline](https://e2-demo-field-eng.cloud.databricks.com/?o=1444828305810485#joblist/pipelines/95f28631-1884-425e-af69-05c3f397dd90) and ingest the raw JSON & CSV data being delivered in our blob storage `/demos/retail/churn/...`. 

# COMMAND ----------

# DBTITLE 1,We'll store the raw data in a USER_BRONZE DELTA table, supporting schema evolution and incorrect data
# MAGIC %sql
# MAGIC -- Note: tables are automatically created during  .writeStream.table("sensor_bronze") operation, but we can also use plain SQL to create them:
# MAGIC CREATE TABLE IF NOT EXISTS sensor_bronze (
# MAGIC   energy   DOUBLE,
# MAGIC   sensor_A DOUBLE,
# MAGIC   sensor_B DOUBLE,
# MAGIC   sensor_C DOUBLE,
# MAGIC   sensor_D DOUBLE,
# MAGIC   sensor_E DOUBLE,
# MAGIC   sensor_F DOUBLE,
# MAGIC   timestamp LONG,
# MAGIC   turbine_id STRING     
# MAGIC   ) using delta tblproperties (
# MAGIC      delta.autooptimize.optimizewrite = TRUE,
# MAGIC      delta.autooptimize.autocompact   = TRUE ); 
# MAGIC -- With these 2 last options, Databricks engine will solve small files & optimize write out of the box!

# COMMAND ----------

def ingest_folder(folder, data_format, table):
  bronze_products = (spark.readStream
                              .format("cloudFiles")
                              .option("cloudFiles.format", data_format)
                              .option("cloudFiles.inferColumnTypes", "true")
                              .option("cloudFiles.schemaLocation", f"{cloud_storage_path}/schema/{table}") #Autoloader will automatically infer all the schema & evolution
                              .load(folder))

  return (bronze_products.writeStream
                    .option("checkpointLocation", f"{cloud_storage_path}/checkpoint/{table}") #exactly once delivery on Delta tables over restart/kill
                    .option("mergeSchema", "true") #merge any new column dynamically
                    .trigger(once = True) #Remove for real time streaming
                    .table(table)) #Table will be created if we haven't specified the schema first
  
ingest_folder('/demos/manufacturing/iot_turbine/historical_turbine_status', 'json', 'historical_turbine_status')
ingest_folder('/demos/manufacturing/iot_turbine/turbine', 'json', 'turbine')
ingest_folder('/demos/manufacturing/iot_turbine/parts', 'json', 'part')
ingest_folder('/demos/manufacturing/iot_turbine/incoming_data', 'json', 'sensor_bronze').awaitTermination()

# COMMAND ----------

# DBTITLE 1,Our user_bronze Delta table is now ready for efficient query
# MAGIC %sql 
# MAGIC -- Note the "_rescued_data" column. If we receive wrong data not matching existing schema, it'll be stored here
# MAGIC select * from sensor_bronze;

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- Note the "_rescued_data" column. If we receive wrong data not matching existing schema, it'll be stored here
# MAGIC select * from turbine;

# COMMAND ----------

# DBTITLE 1,Quick data exploration leveraging pandas on spark (Koalas): sensor from our first turbine
#Let's explore a bit our datasets with pandas on spark.
first_turbine = spark.table('sensor_bronze').limit(1).collect()[0]['turbine_id']
df = spark.table('sensor_bronze').where(f"turbine_id == '{first_turbine}' ").orderBy('timestamp').pandas_api()
df.plot(x="timestamp", y=["sensor_F", "sensor_E"], kind="line")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC 
# MAGIC ## ![](https://pages.databricks.com/rs/094-YMS-629/images/delta-lake-tiny-logo.png) 2/ Silver data: date cleaned
# MAGIC 
# MAGIC <img width="700px" style="float:right" src="https://github.com/databricks-demos/dbdemos-resources/raw/main/images/manufacturing/lakehouse-iot-turbine/lakehouse-manuf-iot-turbine-spark-2.png"/>
# MAGIC 
# MAGIC We can chain these incremental transformation between tables, consuming only new data.
# MAGIC 
# MAGIC This can be triggered in near realtime, or in batch fashion, for example as a job running every night to consume daily data.

# COMMAND ----------

import pyspark.sql.functions as F
#Compute std and percentil of our timeserie per hour
sensors = [c for c in spark.read.table("sensor_bronze").columns if "sensor" in c]
aggregations = [F.avg("energy").alias("avg_energy")]
for sensor in sensors:
  aggregations.append(F.stddev_pop(sensor).alias("std_"+sensor))
  aggregations.append(F.percentile_approx(sensor, [0.1, 0.3, 0.6, 0.8, 0.95]).alias("percentiles_"+sensor))
  
df = (spark.table("sensor_bronze")
          .withColumn("hourly_timestamp", F.date_trunc("hour", F.from_unixtime("timestamp")))
          .groupBy('hourly_timestamp', 'turbine_id').agg(*aggregations))

df.write.mode('overwrite').saveAsTable("sensor_hourly")
display(spark.table("sensor_hourly"))
#Note: a more scalable solution would be to switch to streaming API and compute the aggregation with a ~3hours watermark and MERGE (upserting) the final output. For this demo clarity we we'll go with a full table update instead.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC 
# MAGIC ## ![](https://pages.databricks.com/rs/094-YMS-629/images/delta-lake-tiny-logo.png) 3/ Build our training dataset
# MAGIC 
# MAGIC <img width="700px" style="float:right" src="https://github.com/databricks-demos/dbdemos-resources/raw/main/images/manufacturing/lakehouse-iot-turbine/lakehouse-manuf-iot-turbine-spark-3.png"/>
# MAGIC 
# MAGIC We can chain these incremental transformation between tables, consuming only new data.
# MAGIC 
# MAGIC This can be triggered in near realtime, or in batch fashion, for example as a job running every night to consume daily data.

# COMMAND ----------

turbine = spark.table("turbine")
health = spark.table("historical_turbine_status")
(spark.table("sensor_hourly")
  .join(turbine, ['turbine_id']).drop("row", "_rescued_data")
  .join(health, ['turbine_id'])
  .drop("_rescued_data")
  .write.mode('overwrite').saveAsTable("turbine_training_dataset"))

display(spark.table("turbine_training_dataset"))

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC 
# MAGIC ## ![](https://pages.databricks.com/rs/094-YMS-629/images/delta-lake-tiny-logo.png) 4/ Call the ML model and get realtime turbine metrics
# MAGIC 
# MAGIC <img width="700px" style="float:right" src="https://github.com/databricks-demos/dbdemos-resources/raw/main/images/manufacturing/lakehouse-iot-turbine/lakehouse-manuf-iot-turbine-spark-4.png"/>
# MAGIC 
# MAGIC We can chain these incremental transformation between tables, consuming only new data.
# MAGIC 
# MAGIC This can be triggered in near realtime, or in batch fashion, for example as a job running every night to consume daily data.

# COMMAND ----------

# DBTITLE 1,Load the ML model
# MAGIC %python
# MAGIC #Note: ideally we should download and install the model libraries with the model requirements.txt and PIP. See 04.3-running-inference for an example
# MAGIC import mlflow
# MAGIC #                                                                              Stage/version  
# MAGIC #                                                                 Model name         |        
# MAGIC #                                                                     |              |        
# MAGIC predict_maintenance = mlflow.pyfunc.spark_udf(spark, "models:/dbdemos_turbine_maintenance/Production", "string")
# MAGIC columns = predict_maintenance.metadata.get_input_schema().input_names()

# COMMAND ----------

w = Window.partitionBy("turbine_id").orderBy(col("hourly_timestamp").desc())
(spark.table("sensor_hourly")
  .withColumn("row", F.row_number().over(w))
  .filter(col("row") == 1)
  .join(spark.table('turbine'), ['turbine_id']).drop("row", "_rescued_data")
  .withColumn("prediction", predict_maintenance(*columns))
  .write.mode('overwrite').saveAsTable("current_turbine_metrics"))
#exit notebook
if dbutils.widgets.get("reset_all_data") == "false": dbutils.notebook.exit("ok")

# COMMAND ----------

# MAGIC %sql select * from current_turbine_metrics

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Simplify your operations with transactional DELETE/UPDATE/MERGE operations
# MAGIC 
# MAGIC Traditional Data Lake struggle to run these simple DML operations. Using Databricks and Delta Lake, your data is stored on your blob storage with transactional capabilities. You can issue DML operation on Petabyte of data without having to worry about concurrent operations.

# COMMAND ----------

# DBTITLE 1,We just realised we have to delete bad entry for a specific turbine
spark.sql("DELETE FROM sensor_bronze where turbine_id='"+first_turbine+"'")

# COMMAND ----------

# DBTITLE 1,Delta Lake keeps history of the table operation
# MAGIC %sql describe history sensor_bronze;

# COMMAND ----------

# DBTITLE 1,We can leverage the history to go back in time, restore or clone a table and enable CDC...
# MAGIC %sql 
# MAGIC  --also works with AS OF TIMESTAMP "yyyy-MM-dd HH:mm:ss"
# MAGIC select * from sensor_bronze version as of 1 ;
# MAGIC 
# MAGIC -- You made the DELETE by mistake ? You can easily restore the table at a given version / date:
# MAGIC -- RESTORE TABLE sensor_bronze TO VERSION AS OF 1
# MAGIC 
# MAGIC -- Or clone it (SHALLOW provides zero copy clone):
# MAGIC -- CREATE TABLE sensor_bronze_clone SHALLOW|DEEP CLONE sensor_bronze VERSION AS OF 1
# MAGIC 
# MAGIC -- Turn on CDC to capture insert/update/delete operation:
# MAGIC -- ALTER TABLE sensor_bronze SET TBLPROPERTIES (delta.enableChangeDataFeed = true)

# COMMAND ----------

# DBTITLE 1,Make sure all our tables are optimized
# MAGIC %sql
# MAGIC --Note: can be turned on by default or for all the database
# MAGIC ALTER TABLE turbine                  SET TBLPROPERTIES (delta.autooptimize.optimizewrite = TRUE, delta.autooptimize.autocompact = TRUE );
# MAGIC ALTER TABLE current_turbine_metrics  SET TBLPROPERTIES (delta.autooptimize.optimizewrite = TRUE, delta.autooptimize.autocompact = TRUE );
# MAGIC ALTER TABLE sensor_bronze            SET TBLPROPERTIES (delta.autooptimize.optimizewrite = TRUE, delta.autooptimize.autocompact = TRUE );
# MAGIC ALTER TABLE parts                    SET TBLPROPERTIES (delta.autooptimize.optimizewrite = TRUE, delta.autooptimize.autocompact = TRUE );
# MAGIC ALTER TABLE current_turbine_metrics  SET TBLPROPERTIES (delta.autooptimize.optimizewrite = TRUE, delta.autooptimize.autocompact = TRUE );

# COMMAND ----------

# DBTITLE 1,Our user table will be requested by 2 field mostly, let's optimize the table for that.
# MAGIC %sql
# MAGIC OPTIMIZE sensor_bronze ZORDER BY turbine_id, timestamp

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Our finale tables are now ready to be used to build SQL Dashboards and ML models for customer classification!
# MAGIC <img style="float: right" width="400" src="https://github.com/QuentinAmbard/databricks-demo/raw/main/retail/resources/images/retail-dashboard.png"/>
# MAGIC 
# MAGIC 
# MAGIC Switch to Databricks SQL to see how this data can easily be requested using <a href='/sql/dashboards/1e236ef7-cf58-4bfc-b861-5e6a0c105e51' target="_blank">Churn prediction DBSQL dashboard</a>, or an external BI tool. 
# MAGIC 
# MAGIC Creating a single flow was simple.  However, handling many data pipeline at scale can become a real challenge:
# MAGIC * Hard to build and maintain table dependencies 
# MAGIC * Difficult to monitor & enforce advance data quality
# MAGIC * Impossible to trace data lineage
# MAGIC * Difficult pipeline operations (observability, error recovery)
# MAGIC 
# MAGIC 
# MAGIC #### To solve these challenges, Databricks introduced **Delta Live Table**
# MAGIC A simple way to build and manage data pipelines for fresh, high quality data!

# COMMAND ----------

# MAGIC %md
# MAGIC # Next: secure and share data with Unity Catalog
# MAGIC 
# MAGIC Now that these tables are available in our Lakehouse, let's review how we can share them with the Data Scientists and Data Analysts teams.
# MAGIC 
# MAGIC Jump to the [Governance with Unity Catalog notebook]($../02-Data-governance/02-UC-data-governance-security-churn) or [Go back to the introduction]($../00-churn-introduction-lakehouse)