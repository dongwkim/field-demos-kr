# Databricks notebook source
IMAGE_RESIZE=256
IMAGE_SIZE=768
petastorm_path = 'file:///dbfs/tmp/petastorm/cache'
NUM_EPOCHS=1
BATCH_SIZE=32 